#include <stdint.h>

float Addition(float a, float b);
float Subtraction(float a, float b);
float Division(float a, float b);
float Multiplication(float a, float b);

#include "calculator.h"
#include <stdio.h>

//Sums float variables
float Addition(float a, float b) {
   return a + b;
}

//Subtracts float variables
float Subtraction(float a, float b) {
   return a - b;
}

//Divides float variables
float Division(float a, float b) {
   return a / b;
}

//Multiplies float variables
float Multiplication(float a, float b) {
   return a * b;
}
